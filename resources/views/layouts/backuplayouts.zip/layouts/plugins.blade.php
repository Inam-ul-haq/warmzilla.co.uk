<script type="text/javascript" src="{{asset('js/jquery-3.1.1.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/readmore.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.fancybox.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/owl.carousel.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/web_scripts.js')}}"></script>